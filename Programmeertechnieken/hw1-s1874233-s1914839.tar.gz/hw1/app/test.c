/*  Auteurs         - Jort Gijzen       1874233
                    - Lennard Schaap    1914839
    Studie          - BSc Informatica
    Datum           - 16 februari 2017
    Opdracht        - Building and Linking a library.
    File						- Makefile

    Dit is de test.c file. Deze roept naar de library header. In deze file
    wordt gekeken of deze correct gelinkt is aan de library files.
*/


#include "mylib.h"
#include "stdio.h"

int main () {

  int x = 5;
  int y = 7;

  printf("Dit is telop: %d \n", telop(x, y));
  printf("Dit is vermenigvuldig: %d \n", vermenigvuldig(x, y));
  printf("Dit is modulo: %d \n", modulo(x, y));

  return 0;
}
