/*  Auteurs         - Jort Gijzen       1874233
                    - Lennard Schaap    1914839
    Studie          - BSc Informatica
    Datum           - 16 februari 2017
    Opdracht        - Building and Linking a library.
    File						- Makefile

    Dit is de header file van de library folder. Hierin staan alle functies
    die worden gebruikt in deze opdracht.
*/

#ifndef MYLIB_H
#define MYLIB_H

int telop (int x, int y);
int vermenigvuldig (int x, int y);
int modulo (int x, int y);

#endif
